## ----setup, include=FALSE------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)

## ----eval=FALSE----------------------------------------------------------
#  # gsmr requires the R-package survey
#  install.packages("survey")
#  # install gsmr
#  install.packages("http://cnsgenomics.com/software/gsmr/static/gsmr_1.0.3.tar.gz",repos=NULL,type="source")

## ------------------------------------------------------------------------
library("gsmr")
data("gsmr")
head(gsmr_data)
dim(gsmr_data)

## ----eval=FALSE----------------------------------------------------------
#  # Save the genetic variants and coded alleles in R
#  write.table(gsmr_data[,c(1,2)], "gsmr_example_snps.allele", col.names=F, row.names=F, quote=F)
#  # Extract the genotype data from a PLINK file using GCTA (command line)
#  gcta64 --bfile gsmr_example --extract gsmr_example_snps.allele --update-ref-allele gsmr_example_snps.allele --out gsmr_example

## ----eval=FALSE----------------------------------------------------------
#  # Estimate LD correlation matrix in R
#  snp_coeff_id = scan("gsmr_example.xmat.gz", what="", nlines=1)
#  snp_coeff = read.table("gsmr_example.xmat.gz", header=F, skip=2)

## ------------------------------------------------------------------------
snp_order = match(gsmr_data[,1], snp_coeff_id)
snp_coeff_id = snp_coeff_id[snp_order]
snp_coeff = snp_coeff[, snp_order]
ldrho = cor(snp_coeff)
colnames(ldrho) = rownames(ldrho) = snp_coeff_id
# Check the size of the correlation matrix and double-check if the order of the SNPs in the LD correlation matrix is consistent with that in the GWAS summary data. 

## ------------------------------------------------------------------------
dim(ldrho)
# show the first 5 rows and columns of the matrix  
ldrho[1:5,1:5]

## ----message=FALSE-------------------------------------------------------
snpfreq = gsmr_data$freq             # minor allele frequency of SNPs
bzx = gsmr_data$bzx     # effects of instruments on risk factor
bzx_se = gsmr_data$bzx_se       # standard errors of bzx
bzx_n = gsmr_data$bzx_n          # sample size for GWAS of the risk factor
std_zx = std_effect(snpfreq, bzx, bzx_se, bzx_n)    # perform standardize
gsmr_data$std_bzx = std_zx$b    # standardized bzx
gsmr_data$std_bzx_se = std_zx$se    # standardized bzx_se
head(gsmr_data)

## ----message=FALSE-------------------------------------------------------
bzx = gsmr_data$std_bzx     # SNP effects on risk factor 
bzx_se = gsmr_data$std_bzx_se       # standard errors of bzx
bzx_pval = gsmr_data$bzx_pval    # p-values for bzx
bzy = gsmr_data$bzy     # SNP effects on disease
bzy_se = gsmr_data$bzy_se       # standard errors of bzy
gwas_thresh = 5e-8    # GWAS threshold to select SNPs as the instruments for the GSMR analysis
heidi_thresh = 0.01    # HEIDI-outlier threshold
filtered_index = heidi_outlier(bzx, bzx_se, bzx_pval, bzy, bzy_se, ldrho, snp_coeff_id, gwas_thresh, heidi_thresh) # perform HEIDI-outlier analysis
filtered_gsmr_data = gsmr_data[filtered_index,]   # select data passed HEIDI-outlier filtering
filtered_snp_id = snp_coeff_id[filtered_index]   # select SNPs that passed HEIDI-outlier filtering
dim(gsmr_data)
dim(filtered_gsmr_data)

## ----message=FALSE-------------------------------------------------------
bzx = filtered_gsmr_data$std_bzx    # SNP effects on risk factor
bzx_se = filtered_gsmr_data$std_bzx_se    # standard errors of bzx
bzx_pval = filtered_gsmr_data$bzx_pval   # p-values for bzx
bzy = filtered_gsmr_data$bzy    # SNP effects on disease
bzy_se = filtered_gsmr_data$bzy_se    # standard errors of bzy
filtered_ldrho = ldrho[filtered_gsmr_data$SNP,filtered_gsmr_data$SNP]  # LD correlation matrix of SNPs
gsmr_results = gsmr(bzx, bzx_se, bzx_pval, bzy, bzy_se, filtered_ldrho, filtered_snp_id)    # GSMR analysis 
cat("Effect of exposure on outcome: ",gsmr_results$bxy)
cat("Standard error of bxy: ",gsmr_results$bxy_se)
cat("P-value of bxy: ", gsmr_results$bxy_pval)
cat("Used index to GSMR analysis: ", gsmr_results$used_index[1:5], "...")

## ---- fig.width=6, fig.height=6.5----------------------------------------
effect_col = colors()[75]
vals = c(bzx-bzx_se, bzx+bzx_se)
xmin = min(vals); xmax = max(vals)
vals = c(bzy-bzy_se, bzy+bzy_se)
ymin = min(vals); ymax = max(vals)
par(mar=c(5,5,4,2))
plot(bzx, bzy, pch=20, cex=0.8, bty="n", cex.axis=1.1, cex.lab=1.2,
        col=effect_col, xlim=c(xmin, xmax), ylim=c(ymin, ymax),
        xlab=expression(LDL~cholesterol~(italic(b[zx]))),
        ylab=expression(Coronary~artery~disease~(italic(b[zy]))))
abline(0, gsmr_results$bxy, lwd=1.5, lty=2, col="dim grey")

nsnps = length(bzx)
for( i in 1:nsnps ) {
    # x axis
    xstart = bzx[i] - bzx_se[i]; xend = bzx[i] + bzx_se[i]
    ystart = bzy[i]; yend = bzy[i]
    segments(xstart, ystart, xend, yend, lwd=1.5, col=effect_col)
    # y axis
    xstart = bzx[i]; xend = bzx[i] 
    ystart = bzy[i] - bzy_se[i]; yend = bzy[i] + bzy_se[i]
    segments(xstart, ystart, xend, yend, lwd=1.5, col=effect_col)
}

